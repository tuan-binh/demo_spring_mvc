create
    definer = root@localhost procedure proc_get_all_book()
begin
    select * from books;
end;

